 abc | def
 --- | ---
 bar | foo
 baz | boo
# title
