 abc | def
 --- | ---
 bar | foo
 baz | boo
<div>Some HTML</div>
